export interface Cidade {
    id: number,
    nome: string,
    estado: string,
    latitude: number,
    longitude: number
}